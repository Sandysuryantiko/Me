function toggleTheme() {
    document.body.classList.toggle('light-theme');
  }

  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('active');
      }
    });
  }, {
    threshold: 0.1
  });

  document.querySelectorAll('.section-content').forEach(section => {
    observer.observe(section);
  });
  